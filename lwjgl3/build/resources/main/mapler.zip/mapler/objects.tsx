<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="objects" tilewidth="64" tileheight="64" tilecount="35" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile1.png" width="64" height="64"/>
 </tile>
 <tile id="1">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile2.png" width="64" height="64"/>
 </tile>
 <tile id="2">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile3.png" width="64" height="64"/>
 </tile>
 <tile id="3">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile4.png" width="64" height="64"/>
 </tile>
 <tile id="4">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile5.png" width="64" height="64"/>
 </tile>
 <tile id="5">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile6.png" width="64" height="64"/>
 </tile>
 <tile id="6">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile7.png" width="64" height="64"/>
 </tile>
 <tile id="7">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile8.png" width="64" height="64"/>
 </tile>
 <tile id="8">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile9.png" width="64" height="64"/>
 </tile>
 <tile id="9">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile10.png" width="64" height="64"/>
 </tile>
 <tile id="10">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile11.png" width="64" height="64"/>
 </tile>
 <tile id="11">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile12.png" width="64" height="64"/>
 </tile>
 <tile id="12">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile13.png" width="64" height="64"/>
 </tile>
 <tile id="13">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile14.png" width="64" height="64"/>
 </tile>
 <tile id="14">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile15.png" width="64" height="64"/>
 </tile>
 <tile id="15">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile16.png" width="64" height="64"/>
 </tile>
 <tile id="16">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile17.png" width="64" height="64"/>
 </tile>
 <tile id="17">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile18.png" width="64" height="64"/>
 </tile>
 <tile id="18">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile19.png" width="64" height="64"/>
 </tile>
 <tile id="19">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile20.png" width="64" height="64"/>
 </tile>
 <tile id="20">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile21.png" width="64" height="64"/>
 </tile>
 <tile id="21">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile22.png" width="64" height="64"/>
 </tile>
 <tile id="22">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile23.png" width="64" height="64"/>
 </tile>
 <tile id="23">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile24.png" width="64" height="64"/>
 </tile>
 <tile id="24">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile25.png" width="64" height="64"/>
 </tile>
 <tile id="25">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile26.png" width="64" height="64"/>
 </tile>
 <tile id="26">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile27.png" width="64" height="64"/>
 </tile>
 <tile id="27">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile28.png" width="64" height="64"/>
 </tile>
 <tile id="28">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile29.png" width="64" height="64"/>
 </tile>
 <tile id="29">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile30.png" width="64" height="64"/>
 </tile>
 <tile id="30">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile31.png" width="64" height="64"/>
 </tile>
 <tile id="31">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile32.png" width="64" height="64"/>
 </tile>
 <tile id="32">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile33.png" width="64" height="64"/>
 </tile>
 <tile id="33">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/dark_tiles/dark_tile34.png" width="64" height="64"/>
 </tile>
 <tile id="34">
  <image source="../IMG-20250430-WA0035.png"/>
 </tile>
</tileset>

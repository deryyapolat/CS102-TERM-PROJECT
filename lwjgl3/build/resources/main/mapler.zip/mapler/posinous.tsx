<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="posinous" tilewidth="2047" tileheight="1509" tilecount="15" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile1.png" width="64" height="64"/>
  <animation>
   <frame tileid="0" duration="250"/>
   <frame tileid="1" duration="250"/>
   <frame tileid="2" duration="250"/>
   <frame tileid="3" duration="250"/>
   <frame tileid="4" duration="250"/>
  </animation>
 </tile>
 <tile id="1">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile2.png" width="64" height="64"/>
 </tile>
 <tile id="2">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile3.png" width="64" height="64"/>
 </tile>
 <tile id="3">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile4.png" width="64" height="64"/>
 </tile>
 <tile id="4">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile5.png" width="64" height="64"/>
 </tile>
 <tile id="5">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile6.png" width="64" height="64"/>
  <animation>
   <frame tileid="5" duration="250"/>
   <frame tileid="6" duration="250"/>
   <frame tileid="7" duration="250"/>
   <frame tileid="8" duration="250"/>
   <frame tileid="9" duration="250"/>
  </animation>
 </tile>
 <tile id="6">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile7.png" width="64" height="64"/>
 </tile>
 <tile id="7">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile8.png" width="64" height="64"/>
 </tile>
 <tile id="8">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile9.png" width="64" height="64"/>
 </tile>
 <tile id="9">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/asid_tile10.png" width="64" height="64"/>
 </tile>
 <tile id="10">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/pit1.png" width="64" height="64"/>
 </tile>
 <tile id="11">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/pit2.png" width="64" height="64"/>
 </tile>
 <tile id="12">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/pit3.png" width="64" height="64"/>
 </tile>
 <tile id="13">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/asid_tiles/small_pit.png" width="64" height="64"/>
 </tile>
 <tile id="14">
  <image source="../../Downloads/IMG-20250430-WA0035.png"/>
 </tile>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="background" tilewidth="1920" tileheight="1024" tilecount="7" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/back_ruin_spots.png" width="960" height="541"/>
 </tile>
 <tile id="1">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/Background.png" width="1920" height="1024"/>
 </tile>
 <tile id="2">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/chains.png" width="960" height="541"/>
 </tile>
 <tile id="3">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/floor_ruins.png" width="960" height="541"/>
 </tile>
 <tile id="4">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/ruins_closer.png" width="960" height="541"/>
 </tile>
 <tile id="5">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/ruins_low1.png" width="960" height="541"/>
 </tile>
 <tile id="6">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Background/Pale/ruins_main.png" width="960" height="541"/>
 </tile>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="düzenlenenItemler" tilewidth="80" tileheight="160" tilecount="19" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../düzenlenen itemler/1.PNG" width="80" height="160"/>
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="7" duration="100"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="5" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="1" duration="100"/>
  </animation>
 </tile>
 <tile id="1">
  <image source="../düzenlenen itemler/2.PNG" width="80" height="160"/>
 </tile>
 <tile id="2">
  <image source="../düzenlenen itemler/3.PNG" width="80" height="160"/>
 </tile>
 <tile id="3">
  <image source="../düzenlenen itemler/4.PNG" width="80" height="160"/>
 </tile>
 <tile id="4">
  <image source="../düzenlenen itemler/5.PNG" width="80" height="160"/>
 </tile>
 <tile id="5">
  <image source="../düzenlenen itemler/6.PNG" width="80" height="160"/>
 </tile>
 <tile id="6">
  <image source="../düzenlenen itemler/7.PNG" width="80" height="160"/>
 </tile>
 <tile id="7">
  <image source="../düzenlenen itemler/8.PNG" width="80" height="160"/>
 </tile>
 <tile id="9">
  <image source="../düzenlenen itemler/cornerIce.jpg" width="64" height="64"/>
 </tile>
 <tile id="10">
  <image source="../düzenlenen itemler/iceSlope1.PNG" width="64" height="64"/>
 </tile>
 <tile id="11">
  <image source="../düzenlenen itemler/iceSlope2.PNG" width="64" height="64"/>
 </tile>
 <tile id="12">
  <image source="../düzenlenen itemler/key.png" width="32" height="17"/>
 </tile>
 <tile id="13">
  <image source="../düzenlenen itemler/ortabuz.PNG" width="64" height="64"/>
 </tile>
 <tile id="14">
  <image source="../düzenlenen itemler/sagdanbuz.PNG" width="64" height="64"/>
 </tile>
 <tile id="15">
  <image source="../düzenlenen itemler/soldanbuz.PNG" width="64" height="64"/>
 </tile>
 <tile id="16">
  <image source="../düzenlenen itemler/ropeOrta.PNG" width="64" height="64"/>
 </tile>
 <tile id="17">
  <image source="../düzenlenen itemler/ropeSağ.PNG" width="64" height="64"/>
 </tile>
 <tile id="18">
  <image source="../düzenlenen itemler/ropeSol.PNG" width="64" height="64"/>
 </tile>
 <tile id="19">
  <image source="../düzenlenen itemler/button.PNG" width="64" height="64"/>
 </tile>
</tileset>

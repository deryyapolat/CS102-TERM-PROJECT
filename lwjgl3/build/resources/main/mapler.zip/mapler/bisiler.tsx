<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="items" tilewidth="64" tileheight="64" tilecount="68" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow1.png" width="32" height="32"/>
 </tile>
 <tile id="1">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow2.png" width="32" height="32"/>
 </tile>
 <tile id="2">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow3.png" width="32" height="32"/>
 </tile>
 <tile id="3">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow4.png" width="32" height="32"/>
 </tile>
 <tile id="4">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow5.png" width="32" height="32"/>
 </tile>
 <tile id="5">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow6.png" width="32" height="32"/>
 </tile>
 <tile id="6">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow7.png" width="32" height="32"/>
 </tile>
 <tile id="7">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow8.png" width="32" height="32"/>
 </tile>
 <tile id="8">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow9.png" width="32" height="32"/>
 </tile>
 <tile id="9">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow10.png" width="32" height="32"/>
 </tile>
 <tile id="10">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow11.png" width="32" height="32"/>
 </tile>
 <tile id="11">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow12.png" width="32" height="32"/>
 </tile>
 <tile id="12">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow13.png" width="32" height="32"/>
 </tile>
 <tile id="13">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow14.png" width="32" height="32"/>
 </tile>
 <tile id="14">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow15.png" width="32" height="32"/>
 </tile>
 <tile id="15">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/arrow16.png" width="32" height="32"/>
 </tile>
 <tile id="16">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle1.png" width="32" height="32"/>
 </tile>
 <tile id="17">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle2.png" width="32" height="32"/>
 </tile>
 <tile id="18">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle3.png" width="32" height="32"/>
 </tile>
 <tile id="19">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle4.png" width="32" height="32"/>
 </tile>
 <tile id="20">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle5.png" width="32" height="32"/>
 </tile>
 <tile id="21">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle6.png" width="32" height="32"/>
 </tile>
 <tile id="22">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle7.png" width="32" height="32"/>
 </tile>
 <tile id="23">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle8.png" width="32" height="32"/>
 </tile>
 <tile id="24">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle9.png" width="32" height="32"/>
 </tile>
 <tile id="25">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/bottle10.png" width="32" height="32"/>
 </tile>
 <tile id="26">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin1.png" width="32" height="32"/>
 </tile>
 <tile id="27">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin2.png" width="32" height="32"/>
 </tile>
 <tile id="28">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin3.png" width="32" height="32"/>
 </tile>
 <tile id="29">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin4.png" width="32" height="32"/>
 </tile>
 <tile id="30">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin5.png" width="32" height="32"/>
 </tile>
 <tile id="31">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin6.png" width="32" height="32"/>
 </tile>
 <tile id="32">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin7.png" width="32" height="32"/>
 </tile>
 <tile id="33">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin8.png" width="32" height="32"/>
 </tile>
 <tile id="34">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin9.png" width="32" height="32"/>
 </tile>
 <tile id="35">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/coin10.png" width="32" height="32"/>
 </tile>
 <tile id="36">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal1.png" width="32" height="32"/>
 </tile>
 <tile id="37">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal2.png" width="32" height="32"/>
 </tile>
 <tile id="38">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal3.png" width="32" height="32"/>
 </tile>
 <tile id="39">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal4.png" width="32" height="32"/>
 </tile>
 <tile id="40">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal5.png" width="32" height="32"/>
 </tile>
 <tile id="41">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal6.png" width="32" height="32"/>
 </tile>
 <tile id="42">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal7.png" width="32" height="32"/>
 </tile>
 <tile id="43">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal8.png" width="32" height="32"/>
 </tile>
 <tile id="44">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal9.png" width="32" height="32"/>
 </tile>
 <tile id="45">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/crystal10.png" width="32" height="32"/>
 </tile>
 <tile id="46">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart1.png" width="32" height="32"/>
 </tile>
 <tile id="47">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart2.png" width="32" height="32"/>
 </tile>
 <tile id="48">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart3.png" width="32" height="32"/>
 </tile>
 <tile id="49">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart4.png" width="32" height="32"/>
 </tile>
 <tile id="50">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart5.png" width="32" height="32"/>
 </tile>
 <tile id="51">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart6.png" width="32" height="32"/>
 </tile>
 <tile id="52">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart7.png" width="32" height="32"/>
 </tile>
 <tile id="53">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart8.png" width="32" height="32"/>
 </tile>
 <tile id="54">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart9.png" width="32" height="32"/>
 </tile>
 <tile id="55">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/heart10.png" width="32" height="32"/>
 </tile>
 <tile id="56">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star1.png" width="32" height="32"/>
 </tile>
 <tile id="57">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star2.png" width="32" height="32"/>
 </tile>
 <tile id="58">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star3.png" width="32" height="32"/>
 </tile>
 <tile id="59">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star4.png" width="32" height="32"/>
 </tile>
 <tile id="60">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star5.png" width="32" height="32"/>
 </tile>
 <tile id="61">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star6.png" width="32" height="32"/>
 </tile>
 <tile id="62">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star7.png" width="32" height="32"/>
 </tile>
 <tile id="63">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star8.png" width="32" height="32"/>
 </tile>
 <tile id="64">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star9.png" width="32" height="32"/>
 </tile>
 <tile id="65">
  <image source="../craftpix-671190-dungeon-platformer-pixel-art-tileset/PNG/Items/star10.png" width="32" height="32"/>
 </tile>
 <tile id="66">
  <image source="../icetiled/Key_01.png" width="64" height="64"/>
 </tile>
 <tile id="67">
  <image source="../icetiled/Screenshot_20250430_162035_Google (1).png" width="32" height="32"/>
 </tile>
</tileset>

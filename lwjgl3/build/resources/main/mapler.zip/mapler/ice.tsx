<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="ice" tilewidth="64" tileheight="64" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../Downloads/IMG-20250430-WA0035.png"/>
 </tile>
 <tile id="1">
  <image source="../icetiled/IMG-20250430-WA0020.png" width="64" height="64"/>
 </tile>
 <tile id="2">
  <image source="../icetiled/IMG-20250430-WA0021.png" width="64" height="64"/>
 </tile>
 <tile id="3">
  <image source="../icetiled/IMG-20250430-WA0035.png" width="64" height="64"/>
 </tile>
 <tile id="5">
  <image source="../icetiled/Key_01.png" width="64" height="64"/>
 </tile>
 <tile id="6">
  <image source="../icetiled/Screenshot_20250430_162035_Google (1).png" width="32" height="64"/>
 </tile>
</tileset>
